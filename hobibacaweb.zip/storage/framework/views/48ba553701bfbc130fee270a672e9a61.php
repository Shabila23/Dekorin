<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Selamat Datang Admin, Ganteng!</h2>
    <p>Ini adalah halaman dashboard untuk admin.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hobibacaweb\resources\views/welcome.blade.php ENDPATH**/ ?>