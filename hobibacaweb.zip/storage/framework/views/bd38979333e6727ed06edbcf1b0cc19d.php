<?php $__env->startSection('title', 'Data Transaksi'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .coin {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            background-color: #ffeb3b;
            /* Kuning cerah */
            border: 2px solid #fbc02d;
            /* Border kuning gelap */
            border-radius: 50%;
            /* Membuat lingkaran */
            font-weight: bold;
            font-size: 12px;
            color: #795548;
            /* Warna coklat tua untuk kontras */
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            /* Sedikit bayangan agar terlihat mengambang */
            user-select: none;
            /* Agar teks tidak bisa diseleksi */
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Buku</th>
                <th>Keterangan</th>
                <th>Status</th>
                <th>Biaya</th>
                <th>Created at</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($transaction->id); ?></td>
                <td><?php echo e($transaction->user->name ?? '-'); ?></td>
                <td><?php echo e($transaction->book->title ?? '-'); ?></td>
                <td><?php echo e($transaction->keterangan); ?></td>
                <td>
                    <?php
                        $statusClass = match ((int) $transaction->status) {
                            0 => 'badge bg-warning',
                            1 => 'badge bg-success',
                            2 => 'badge bg-danger',
                            default => 'badge bg-secondary',
                        };
                    ?>
                    <span class="<?php echo e($statusClass); ?>"><?php echo e($transaction->status_text); ?></span>
                </td>
                <td><span class="coin">$</span> <?php echo e(number_format($transaction->biaya, 0, ',', '.')); ?></td>
                <td><small><i><?php echo e($transaction->created_at->format('d-m-Y H:i:s')); ?></i></small></td>
                <td>
                    <a href="<?php echo e(route('transactions.edit', $transaction->id)); ?>" class="btn btn-primary btn-sm">Edit</a>

                    <form action="<?php echo e(route('transactions.destroy', $transaction->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Yakin ingin menghapus transaksi ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center text-danger">Tidak ada data transaksi.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($transactions->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hobibacaweb\resources\views/transactions/index.blade.php ENDPATH**/ ?>