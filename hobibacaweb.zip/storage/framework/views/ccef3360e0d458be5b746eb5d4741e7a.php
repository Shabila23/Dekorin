<?php $__env->startSection('title', 'Need Approval Transactions'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .coin {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            background-color: #ffeb3b;
            /* Kuning cerah */
            border: 2px solid #fbc02d;
            /* Border kuning gelap */
            border-radius: 50%;
            /* Membuat lingkaran */
            font-weight: bold;
            font-size: 12px;
            color: #795548;
            /* Warna coklat tua untuk kontras */
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
            /* Sedikit bayangan agar terlihat mengambang */
            user-select: none;
            /* Agar teks tidak bisa diseleksi */
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($transactions->isEmpty()): ?>
        <p>Tidak ada transaksi pending saat ini.</p>
    <?php else: ?>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>User</th>
                    <th>Keterangan</th>
                    <th>Biaya</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transaction->created_at->format('d-m-Y H:i')); ?></td>
                    <td><?php echo e($transaction->user->name ?? 'User tidak ditemukan'); ?></td>
                    <td><?php echo e($transaction->keterangan); ?></td>
                    <td><span class="coin">$</span> <?php echo e(number_format($transaction->biaya, 0, ',', '.')); ?></td>
                    <td>
                        <?php if($transaction->status == '0'): ?>
                            <span class="badge bg-warning text-dark">Pending</span>
                        <?php elseif($transaction->status == '1'): ?>
                            <span class="badge bg-success">Sukses</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Gagal</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form action="<?php echo e(route('transactions.approve', $transaction->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Setujui transaksi ini?')">Approve</button>
                        </form>

                        <form action="<?php echo e(route('transactions.reject', $transaction->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tolak transaksi ini?')">Tolak</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hobibacaweb\resources\views/transactions/approval.blade.php ENDPATH**/ ?>