

<?php $__env->startSection('title', 'Dekorin'); ?>

<?php $__env->startSection('content'); ?>
    <h2>List Dekorin</h2>

    <?php if($dekorins->isEmpty()): ?>
        <div class="alert alert-info">
            Belum ada data Dekorin.
        </div>
    <?php else: ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tema</th>
                    <th>category</th>
                    <th>Harga</th>
                    <th>Rating</th>
                    <th>Tgl Terbit</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dekorins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dekorin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($dekorin->tema); ?></td>
                        <td><?php echo e($dekorin->category->category ?? '-'); ?></td> 
                        <td>Rp<?php echo e(number_format($dekorin->price, 0, ',', '.')); ?></td>
                        <td><?php echo e($dekorin->rating); ?>/5</td>
                        <td><?php echo e($dekorin->tgl_terbit?->format('d-m-Y') ?? '-'); ?></td>
                        <td>
                            <a href="<?php echo e(route('dekorins.edit', $dekorin->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('dekorins.destroy', $dekorin->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a href="<?php echo e(route('dekorins.create')); ?>" class="btn btn-primary mt-3">+ Tambah Dekorin</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hobibacaweb\resources\views/dekorins/index.blade.php ENDPATH**/ ?>