@extends('template')
@section('title', 'Dashboard')
@section('content')
    <h2>Selamat Datang Admin, Ganteng!</h2>
    <p>Ini adalah halaman dashboard untuk admin.</p>
@endsection
